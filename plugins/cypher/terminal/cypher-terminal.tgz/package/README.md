# Cypher terminal

Requires Node.js 24 or newer. Install the packaged archive, not a development
folder, so the installed commands are independent of a checkout:

```sh
npm install -g ./cypher-terminal.tgz
```

`cypher-open` adds Cypher beside an existing tmux pane. Outside tmux on macOS it
opens Terminal; other platforms explain how to open another terminal. To start
Codex and Cypher together, run `cypher-open --start` directly in your terminal.
That mode requires `tmux` and `codex` on PATH. Switch panes with Ctrl+B then an
arrow; `/exit` closes Cypher. Detaching tmux leaves its processes running.

`cypher-open` connects to https://cypherchat.org and uses Codex sign-in consent:
a guest launch does not read Keychain. After successful login, choose Save to
remember the sign-in or Not now to keep it for this session. Saved sign-ins can
restore on later launches. Keychain denial does not end the current login.

`cypher --origin https://cypherchat.org --codex` runs directly in the current
human-controlled terminal. Use `--session-only` to disable saving, `--origin URL`
to choose another service, and `--join INVITE` for an invitation. HTTPS is required
except for loopback development. Run either command with `--help` for options.

The human uses `/signin`, `/verify`, and `/signout` in Cypher. Agents may run the
non-interactive `cypher-open` launcher, but must not attach to the room, capture
terminal content, or run the interactive client through output-capturing tools.
The service stays hosted; this package supplies only the local terminal client.
