---
name: cypher-chat
description: Open the human-operated Cypher terminal beside an existing Codex session, or provide the command to start both together. Use only for an explicit terminal request or an explicitly identified Codex CLI host. Never use for a plain open Cypher request in ChatGPT or Codex desktop.
---

ChatGPT web/desktop/mobile/Work and Codex desktop use the inline Cypher plugin
for ordinary launch requests. Do not run this terminal skill there unless the
person explicitly asks for a terminal. Shell tools or a local workspace do not
identify the host as Codex CLI. When uncertain, use the inline plugin.

For an existing Codex session, run the installed `cypher-open` launcher. It
splits the inherited tmux pane without restarting Codex or its agents. When the
user supplies a known tmux pane ID, pass it with `--pane`; never guess a target
or inspect terminal content to find one. On macOS without tmux context, the
launcher opens a separate Terminal window and reports that fallback honestly.
On other platforms without tmux context, provide the separate-terminal command.

For a user about to start Codex, provide `cypher-open --start` to run directly
in their terminal. Codex arguments go after `--`. Do not run this mode through
an agent shell tool: attachment would capture the interactive session.

The launcher defaults to https://cypherchat.org. Pass an explicit user-supplied
service with `--origin` and an invite with `--join` using safely quoted arguments.
If the launcher is missing, point to the package README's build/install steps;
do not silently fall back to the MCP QR doorway for a terminal request.

Only the non-interactive `cypher-open` launcher may run through an agent tool.
Never run `cypher` itself, attach to tmux, capture panes, read credentials or
conversations, or operate room actions and sign-in for the user. Report only
launcher status. The human switches panes with Ctrl+B then an arrow and closes
Cypher with /exit. Closing Cypher leaves Codex running.

This optional skill does not replace the hosted inline-app plugin.
