#!/usr/bin/env node

// src/cli/launch.ts
import { spawnSync } from "node:child_process";
import { existsSync, realpathSync } from "node:fs";
import { delimiter, join, dirname } from "node:path";
import { fileURLToPath } from "node:url";
import { parseArgs } from "node:util";
import { randomUUID } from "node:crypto";

// src/cli/api.ts
function normalizeOrigin(value) {
  const u = new URL(value);
  if (u.username || u.password || u.pathname !== "/" || u.search || u.hash || !(u.protocol === "https:" || u.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(u.hostname)))
    throw Error("Use an HTTPS origin, or HTTP on localhost.");
  return u.origin;
}

// src/cli/launch.ts
function shellQuote(value) {
  return "'" + value.replaceAll("'", "'\\''") + "'";
}
function terminalScript(argv, cwd) {
  const command = `cd ${shellQuote(cwd)} && exec ${argv.map(shellQuote).join(" ")}`;
  const literal = '"' + command.replaceAll("\\", "\\\\").replaceAll('"', '\\"') + '"';
  return `tell application "Terminal"
activate
do script ${literal}
end tell`;
}
function available(command) {
  return (process.env.PATH ?? "").split(delimiter).some((dir) => existsSync(join(dir, command)));
}
function main(args = process.argv.slice(2)) {
  const separator = args.indexOf("--");
  const codexArgs = separator < 0 ? [] : args.slice(separator + 1);
  const { values } = parseArgs({
    args: separator < 0 ? args : args.slice(0, separator),
    options: {
      start: { type: "boolean" },
      pane: { type: "string" },
      origin: { type: "string", default: "https://cypherchat.org" },
      join: { type: "string" },
      "session-only": { type: "boolean" },
      help: { type: "boolean", short: "h" }
    }
  });
  if (values.help) {
    console.log(`cypher-open [--pane %ID] [--origin URL] [--join INVITE] [--session-only]
  Open Cypher beside an existing tmux pane; macOS otherwise opens Terminal.
cypher-open --start [options] -- [codex arguments]
  Start Codex and Cypher together in a new tmux session (human terminal only).
Switch panes: Ctrl+B then arrow. Close Cypher: /exit. Detach: Ctrl+B then D.
Requires the built Cypher terminal package; --start also needs tmux and codex.`);
    return;
  }
  if (!values.start && codexArgs.length) throw Error("Codex arguments require --start.");
  if (values.start && values.pane) throw Error("Use --pane for an existing session, or --start for a new one.");
  const origin = normalizeOrigin(values.origin);
  const client = join(dirname(fileURLToPath(import.meta.url)), "cypher.js");
  if (!existsSync(client)) throw Error("Build and install the terminal package first: npm run build:cli");
  const cypher = [process.execPath, client, "--origin", origin, "--codex"];
  if (values.join) cypher.push("--join", values.join);
  if (values["session-only"]) cypher.push("--session-only");
  const cwd = process.cwd();
  const run = (command, argv, interactive = false) => {
    const result = spawnSync(command, argv, { stdio: interactive ? "inherit" : "ignore" });
    if (result.error || result.status !== 0) throw Error(`${command} could not complete the launch.`);
  };
  if (values.start) {
    if (!process.stdin.isTTY || !process.stdout.isTTY)
      throw Error("Run --start directly in your terminal, not through an agent tool.");
    if (process.env.TMUX) throw Error("Already inside tmux: use cypher-open to add Cypher beside this pane.");
    if (!available("tmux") || !available("codex")) throw Error("Install tmux and Codex before using --start.");
    const session = `cypher-${randomUUID()}`;
    run("tmux", ["new-session", "-d", "-s", session, "-c", cwd, "codex", ...codexArgs]);
    try {
      run("tmux", ["split-window", "-h", "-d", "-l", "35%", "-t", `${session}:0.0`, "-c", cwd, ...cypher]);
    } catch (error) {
      spawnSync("tmux", ["kill-session", "-t", session], { stdio: "ignore" });
      throw error;
    }
    run("tmux", ["attach-session", "-t", session], true);
    return;
  }
  const pane = values.pane ?? process.env.TMUX_PANE;
  if (pane) {
    if (!/^%[0-9]+$/.test(pane)) throw Error("The tmux pane must be an ID such as %0.");
    if (!available("tmux")) throw Error("tmux is required to split an existing pane.");
    run("tmux", ["split-window", "-h", "-d", "-l", "35%", "-t", pane, "-c", cwd, ...cypher]);
    console.log("Cypher opened beside your session. Ctrl+B then an arrow switches panes.");
  } else if (process.platform === "darwin") {
    run("osascript", ["-e", terminalScript(cypher, cwd)]);
    console.log("Cypher opened in Terminal. This session has no tmux pane to split.");
  } else {
    throw Error("No tmux pane found. Run cypher in a separate terminal, or start both with cypher-open --start.");
  }
}
if (process.argv[1] && realpathSync(fileURLToPath(import.meta.url)) === realpathSync(process.argv[1])) {
  try {
    main();
  } catch (error) {
    console.error(error instanceof Error ? error.message : "Could not open Cypher.");
    process.exitCode = 1;
  }
}
export {
  main,
  shellQuote,
  terminalScript
};
