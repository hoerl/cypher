#!/usr/bin/env node

// src/cli/main.tsx
import { render } from "ink";
import { parseArgs } from "node:util";

// src/cli/controller.ts
import { spawn as spawn2 } from "node:child_process";

// src/cli/qr.ts
import QRCode from "qrcode";
function qrLines(url) {
  const matrix = QRCode.create(url, { errorCorrectionLevel: "L" }).modules, lines = [];
  const dark = (x, y) => !!(x >= 4 && y >= 4 && x < matrix.size + 4 && y < matrix.size + 4 && matrix.get(y - 4, x - 4));
  for (let y = 0; y < matrix.size + 8; y += 2) {
    const row = [];
    for (let x = 0; x < matrix.size + 8; x++) {
      const top = dark(x, y), bottom = dark(x, y + 1);
      const run = {
        text: top === bottom ? " " : "\u2584",
        foreground: bottom ? "black" : "white",
        background: top ? "black" : "white"
      };
      const previous = row.at(-1);
      if (previous?.foreground === run.foreground && previous.background === run.background)
        previous.text += run.text;
      else row.push(run);
    }
    lines.push(row);
  }
  return lines;
}

// src/shared/contracts.ts
import { z } from "zod";
var DEFAULT_ROOM_TOPIC = "Situation Room";
var DEFAULT_HUMAN_ROOM_TOPIC = "backrooms";
var roomName = (topic) => topic.normalize("NFKC").trim().replace(/\s+/g, " ").toLowerCase();
var isDefaultRoom = (topic) => [DEFAULT_ROOM_TOPIC, DEFAULT_HUMAN_ROOM_TOPIC].some(
  (name) => roomName(name) === roomName(topic)
);
var isBuiltIn = (room) => room.builtIn ?? isDefaultRoom(room.topic);
var entryRoom = (rooms) => rooms.find(
  (room) => isBuiltIn(room) && roomName(room.topic) === roomName(DEFAULT_ROOM_TOPIC)
);
var INVITE_CODE = /^[A-Z2-9]{6}$/;
var INVITE_PARAMETER = /[?&]join=([A-Za-z0-9]{6})(?![A-Za-z0-9])/;
function inviteCode(input) {
  const text = input.trim();
  const code = (INVITE_PARAMETER.exec(text)?.[1] ?? text).toUpperCase();
  return INVITE_CODE.test(code) ? code : null;
}
var inviteLink = (origin, code) => `${origin}/?join=${code}`;
var DAY = 864e5;
var GUEST_MESSAGE_LIFETIME = 3e4;
var THREAD_INITIAL_LIFETIME = 7 * DAY;
var THREAD_EXTENSION = 3 * DAY;
var accountKind = (member) => member.accountKind ?? (member.id.startsWith("guest:") ? "guest" : "world");
var isHuman = (member) => member.humanVerified === true;
var messageLifetime = (member) => (typeof member === "string" || !isHuman(member)) && accountKind(typeof member === "string" ? { id: member } : member) === "guest" ? GUEST_MESSAGE_LIFETIME : Infinity;
var gamertagSchema = z.string().trim().regex(/^[A-Za-z][A-Za-z0-9_]{2,23}$/);
var topicSchema = z.string().trim().min(1).max(100).regex(/^[^\x00-\x1f\x7f-\x9f\u2028\u2029\u202a-\u202e\u2066-\u2069]*$/);
var pubkeySchema = z.string().regex(/^[a-f0-9]{64}$/);
var commandSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("read"), roomId: z.string().uuid(), messageId: z.string().regex(/^[a-f0-9]{64}$/) }),
  z.object({ type: z.literal("deleteMessage"), messageId: z.string().regex(/^[a-f0-9]{64}$/) }),
  z.object({ type: z.literal("deleteRoom"), roomId: z.string().uuid() }),
  z.object({ type: z.literal("join"), roomId: z.string().uuid() }),
  z.object({ type: z.literal("leave") }),
  z.object({
    type: z.literal("permissions"),
    roomId: z.string().uuid(),
    humanOnly: z.boolean()
  }),
  z.object({ type: z.literal("create"), topic: topicSchema }),
  z.object({ type: z.literal("away"), text: z.string().trim().max(100) }),
  z.object({ type: z.literal("activity") }),
  z.object({ type: z.literal("typing"), roomId: z.string().uuid(), active: z.boolean() }),
  z.object({
    type: z.literal("ignore"),
    memberId: z.string(),
    ignored: z.boolean()
  }),
  z.object({
    type: z.literal("kick"),
    memberId: z.string(),
    banned: z.boolean()
  })
]);

// src/cli/clipboard.ts
import { spawn } from "node:child_process";
var TOOL_TIMEOUT_MS = 3e3;
var TOOLS = {
  darwin: [["pbcopy", []]],
  win32: [["clip", []]],
  linux: [
    ["wl-copy", []],
    ["xclip", ["-selection", "clipboard"]]
  ]
};
function pipe(command, args, text) {
  return new Promise((resolve) => {
    const child = spawn(command, args, {
      stdio: ["pipe", "ignore", "ignore"],
      shell: false,
      timeout: TOOL_TIMEOUT_MS
    });
    child.on("error", () => resolve(false));
    child.on("exit", (code) => resolve(code === 0));
    child.stdin.on("error", () => resolve(false));
    child.stdin.end(text);
  });
}
async function copyText(text, platform = process.platform) {
  for (const [command, args] of TOOLS[platform] ?? [])
    if (await pipe(command, args, text)) return true;
  return false;
}

// src/shared/welcome.ts
function welcomeFor(prev, next, isNew) {
  if (!prev || accountKind(next) === "guest" || next.needsName) return null;
  if (accountKind(prev) === "guest")
    return isNew ? `You\u2019re ${next.gamertag}.` : "Welcome back.";
  if (prev.needsName && prev.id === next.id) return `Welcome, ${next.gamertag}`;
  return null;
}

// src/client/protocol.ts
import { z as z2 } from "zod";
var memberSchema = z2.object({
  id: z2.string().max(256),
  gamertag: z2.string().max(100),
  host: z2.boolean(),
  superAdmin: z2.boolean().optional(),
  accountKind: z2.enum(["guest", "passkey", "world", "reviewer", "nostr"]).optional(),
  humanVerified: z2.boolean().optional(),
  hasPasskey: z2.boolean().optional(),
  needsName: z2.boolean().optional()
});
var snapshot = z2.object({
  lockedRoomCount: z2.number().int().nonnegative().max(1e4).optional(),
  serverTime: z2.number().optional(),
  historyLimited: z2.boolean().optional(),
  typingUntil: z2.number().finite().optional(),
  presentCount: z2.number().int().nonnegative(),
  self: memberSchema,
  // Guests only: ephemeral posts left today (0 means read-only).
  guestPostsLeft: z2.number().int().nonnegative().optional(),
  rooms: z2.array(
    z2.object({
      id: z2.string(),
      topic: z2.string().max(100),
      updatedAt: z2.number(),
      count: z2.number(),
      humanOnly: z2.boolean().optional(),
      builtIn: z2.boolean().optional(),
      threadId: z2.string().optional(),
      threadExpiresAt: z2.number().optional(),
      closingSoon: z2.boolean().optional(),
      code: z2.string().regex(INVITE_CODE).optional()
    })
  ).max(1e4),
  roomId: z2.string().nullable(),
  members: z2.array(
    memberSchema.extend({
      roomId: z2.string().nullable(),
      away: z2.string(),
      idle: z2.boolean()
    })
  ).max(1e4),
  messages: z2.array(
    z2.object({
      id: z2.string(),
      memberId: z2.string(),
      gamertag: z2.string(),
      text: z2.string().max(500),
      createdAt: z2.number(),
      expiresAt: z2.number().nullable().transform((v) => v ?? Infinity),
      replyTo: z2.string().nullable(),
      guest: z2.boolean().optional(),
      superAdmin: z2.boolean().optional(),
      humanVerified: z2.boolean().optional()
    })
  ).max(1e4),
  ignored: z2.array(z2.string()),
  banned: z2.array(memberSchema)
});
var frame = z2.union([
  z2.tuple([z2.literal("AUTH"), z2.string().max(1024)]),
  z2.tuple([z2.literal("SPACE"), snapshot]),
  z2.tuple([z2.literal("OK"), z2.string(), z2.boolean(), z2.string()])
]);
function parseFrame(raw) {
  if (raw.length > 8e6) throw Error("Response too large");
  return frame.parse(JSON.parse(raw));
}
var sessionSchema = z2.object({
  token: z2.string().regex(/^[A-Za-z0-9_-]{43}$/),
  expiresAt: z2.number().finite().positive(),
  member: memberSchema.nullable()
});

// src/cli/client.ts
import { randomBytes } from "node:crypto";
import { getPublicKey as getPublicKey2 } from "nostr-tools";
import WebSocket from "ws";
import { z as z3 } from "zod";

// src/client/transport.ts
import { finalizeEvent, generateSecretKey } from "nostr-tools";
var RoomTransport = class {
  constructor(update, status, error, socketFactory) {
    this.update = update;
    this.status = status;
    this.error = error;
    this.socketFactory = socketFactory;
  }
  update;
  status;
  error;
  socketFactory;
  key = generateSecretKey();
  socket;
  reconnect;
  disposed = false;
  attempts = 0;
  entered = false;
  /** An invite code still to follow: the room to enter by, or to move to. */
  invite;
  /**
   * Where a failed invite is said. Unset, it goes to the error line; a client
   * whose error line is cleared by the next room update sets its own.
   */
  inviteProblem;
  bootstrap;
  clockOffset = 0;
  /** Gamertag last published as this mount key's kind 0, per socket. */
  profileName;
  pending = /* @__PURE__ */ new Map();
  config;
  session;
  snapshot;
  setBootstrap(value) {
    this.bootstrap = value;
  }
  get token() {
    if (!this.session) throw Error("Cypher is still connecting.");
    return this.session.token;
  }
  connect() {
    if (this.disposed || !this.config || !this.session || this.socket && this.socket.readyState <= 1)
      return;
    clearTimeout(this.reconnect);
    this.status(this.attempts ? "reconnecting" : "connecting");
    const ws = this.socketFactory(this.config.relayUrl);
    this.socket = ws;
    this.profileName = void 0;
    ws.onmessage = (e) => {
      if (this.disposed || this.socket !== ws) return;
      try {
        const frame2 = parseFrame(String(e.data));
        if (frame2[0] === "AUTH") {
          const event = finalizeEvent(
            {
              kind: 22242,
              created_at: Math.floor(Date.now() / 1e3),
              content: "",
              tags: [
                ["relay", this.config.relayUrl],
                ["challenge", frame2[1]],
                ["token", this.token]
              ]
            },
            this.key
          );
          ws.send(JSON.stringify(["AUTH", event]));
        } else if (frame2[0] === "SPACE") {
          const prior = this.snapshot;
          this.snapshot = frame2[1];
          this.clockOffset = (this.snapshot.serverTime ?? Date.now()) - Date.now();
          this.update(this.snapshot);
          this.status("connected");
          this.publishName(this.snapshot.self.gamertag);
          this.attempts = 0;
          if (prior?.roomId && !this.snapshot.roomId && this.restoreRoom) {
            const roomId = prior.roomId;
            this.restoreRoom = false;
            void this.command({ type: "join", roomId }).catch(
              (e2) => this.error(e2.message)
            );
          } else this.restoreRoom = false;
          if (!this.entered) {
            this.entered = true;
            const situation = entryRoom(this.snapshot.rooms);
            if (this.invite && this.followInvite(situation?.id)) return;
            if (!this.snapshot.roomId && situation)
              void this.command({ type: "join", roomId: situation.id }).catch(
                (e2) => this.error(e2.message)
              );
          }
        } else if (frame2[0] === "OK") {
          const p = this.pending.get(frame2[1]);
          if (p) {
            clearTimeout(p.timer);
            this.pending.delete(frame2[1]);
            frame2[2] ? p.resolve() : p.reject(Error(frame2[3]));
          } else if (!frame2[2]) this.error(frame2[3]);
        }
      } catch {
        this.error("The connection returned an invalid response.");
        ws.close();
      }
    };
    ws.onclose = (e) => {
      if (this.socket !== ws) return;
      this.failPending();
      if (this.disposed) return;
      if (++this.attempts > 6) {
        this.status("closed");
        this.error("Your session ended. Reopen Cypher to sign in.");
        return;
      }
      this.status("reconnecting");
      this.restoreRoom = true;
      this.reconnect = setTimeout(
        () => {
          if (e.code === 4001 || Date.now() > this.session.expiresAt) {
            this.session = void 0;
            void this.initialize(this.bootstrap).then(() => {
              if (!this.disposed) this.connect();
            }).catch((error) => {
              this.error(error.message);
              this.status("closed");
            });
          } else this.connect();
        },
        Math.min(1e3 * 2 ** (this.attempts - 1), 15e3)
      );
    };
    ws.onerror = () => this.error("Connection interrupted. Reconnecting\u2026");
  }
  expiryTimer = setInterval(() => {
    if (!this.snapshot) return;
    const now = Date.now() + this.clockOffset;
    if (!this.snapshot.messages.some((m) => m.expiresAt <= now && m.text))
      return;
    this.snapshot = {
      ...this.snapshot,
      messages: this.snapshot.messages.filter(
        (m) => (m.guest ?? m.memberId.startsWith("guest:")) || m.expiresAt > now || this.snapshot.messages.some(
          (r) => r.replyTo === m.id && r.expiresAt > now
        )
      ).map(
        (m) => m.expiresAt <= now ? { ...m, text: "", replyTo: null } : m
      )
    };
    this.update(this.snapshot);
  }, 250);
  restoreRoom = false;
  send(frame2, id) {
    return new Promise((resolve, reject) => {
      if (this.socket?.readyState !== 1) {
        reject(Error("Wait for the room to reconnect."));
        return;
      }
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(
          Error(
            "Delivery was not confirmed. Check the room before sending again."
          )
        );
      }, 1e4);
      this.pending.set(id, { resolve, reject, timer });
      this.socket.send(JSON.stringify(frame2));
    });
  }
  /**
   * Enters by an invite link or code. Before the first room list arrives it
   * replaces the default room; after, it moves there. False when `input`
   * holds no code at all.
   */
  enterBy(input) {
    const code = inviteCode(input);
    if (!code) return false;
    this.invite = code;
    if (this.entered) this.followInvite();
    return true;
  }
  /**
   * Joins the invited room when this person may see it; says so when not.
   * A room that is listed can still refuse (full, removed): on entry that
   * ends in `fallback`, so nobody is left in no room.
   */
  followInvite(fallback) {
    const refused = (message) => (this.inviteProblem ?? this.error)(message);
    const room = this.snapshot?.rooms.find((r) => r.code === this.invite);
    this.invite = void 0;
    if (!room) {
      refused("That room is unavailable.");
      return false;
    }
    if (room.id !== this.snapshot?.roomId)
      void this.command({ type: "join", roomId: room.id }).catch((e) => {
        refused(e.message);
        if (fallback && !this.snapshot?.roomId)
          void this.command({ type: "join", roomId: fallback }).catch(
            (e2) => this.error(e2.message)
          );
      });
    return true;
  }
  command(command) {
    const id = crypto.randomUUID();
    return this.send(["SPACE", id, command], id);
  }
  post(text, replyTo) {
    if (!this.snapshot?.roomId)
      return Promise.reject(Error("Join a room first."));
    const created_at = Math.floor(Date.now() / 1e3);
    const tags = [["h", this.snapshot.roomId]];
    const lifetime = messageLifetime(this.snapshot.self);
    if (Number.isFinite(lifetime))
      tags.push(["expiration", String(created_at + lifetime / 1e3)]);
    if (replyTo) tags.push(["e", replyTo]);
    const event = finalizeEvent(
      { kind: 9, created_at, content: text, tags },
      this.key
    );
    return this.send(["EVENT", event], event.id);
  }
  /**
   * Nostr clients in the room see this mount's posts by pubkey; a kind 0 signed
   * by the same short-lived key lets them show the gamertag instead. The relay
   * keeps it in memory only while this session is connected.
   */
  publishName(name) {
    if (this.profileName === name) return;
    this.profileName = name;
    const event = finalizeEvent(
      {
        kind: 0,
        created_at: Math.floor(Date.now() / 1e3),
        content: JSON.stringify({ name }),
        tags: []
      },
      this.key
    );
    void this.send(["EVENT", event], event.id).catch(() => {
      this.profileName = void 0;
    });
  }
  failPending() {
    for (const p of this.pending.values()) {
      clearTimeout(p.timer);
      p.reject(
        Error(
          "Connection lost. Delivery may have completed; check the room before retrying."
        )
      );
    }
    this.pending.clear();
  }
  close() {
    if (this.disposed) return;
    this.disposed = true;
    clearInterval(this.expiryTimer);
    clearTimeout(this.reconnect);
    this.socket?.close(1e3, "Portal closed");
    this.failPending();
    this.key.fill(0);
    this.snapshot = void 0;
    this.status("closed");
  }
};

// src/cli/api.ts
var ApiError = class extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
  status;
};
function normalizeOrigin(value) {
  const u = new URL(value);
  if (u.username || u.password || u.pathname !== "/" || u.search || u.hash || !(u.protocol === "https:" || u.protocol === "http:" && ["127.0.0.1", "localhost", "[::1]"].includes(u.hostname)))
    throw Error("Use an HTTPS origin, or HTTP on localhost.");
  return u.origin;
}
function createApi(origin, lifetime) {
  return async function request(path, token, body, method = "POST") {
    const response = await fetch(origin + path, {
      method,
      redirect: "error",
      signal: AbortSignal.any([lifetime, AbortSignal.timeout(15e3)]),
      headers: {
        "X-Cypher-Client": "terminal",
        ...token ? { Authorization: `Bearer ${token}` } : {},
        ...body ? { "Content-Type": "application/json" } : {}
      },
      body: body ? JSON.stringify(body) : void 0
    }).catch(() => {
      throw Error("Connection interrupted. Try again.");
    });
    if (response.status === 204) return void 0;
    const data = await response.json().catch(() => {
      throw Error("Invalid server response.");
    });
    if (!response.ok)
      throw new ApiError(
        response.status,
        typeof data.error === "string" ? data.error : "Request failed."
      );
    return data;
  };
}

// src/cli/client.ts
var TerminalClient = class extends RoomTransport {
  constructor(origin, store, update, status, error) {
    origin = normalizeOrigin(origin);
    super(
      update,
      status,
      error,
      (url) => new WebSocket(url, {
        origin,
        maxPayload: 8e6
      })
    );
    this.store = store;
    this.origin = origin;
    this.request = createApi(origin, this.lifetime.signal);
  }
  store;
  lifetime = new AbortController();
  request;
  origin;
  credential = null;
  loaded = false;
  initializing;
  initialize() {
    return this.initializing ??= this.start().finally(() => {
      this.initializing = void 0;
    });
  }
  async start() {
    if (!this.loaded) {
      this.credential = await this.store?.load() ?? null;
      this.loaded = true;
    }
    if (this.credential?.revoking) {
      await this.request("/api/terminal/revoke", void 0, {
        secret: this.credential.secret
      });
      await this.store?.clear();
      this.credential = null;
    }
    if (!this.config) {
      this.config = z3.object({
        origin: z3.string().url().optional(),
        relayUrl: z3.string().url(),
        development: z3.boolean(),
        worldConfigured: z3.boolean(),
        guestTesting: z3.boolean()
      }).parse(await this.request("/api/config", void 0, void 0, "GET"));
      const relay = new URL(this.config.relayUrl);
      if (relay.origin !== this.origin.replace(/^http/, "ws") || relay.pathname !== "/relay")
        throw Error("The service returned an unexpected relay.");
    }
    if (!this.session && this.credential) {
      try {
        this.session = await this.requestSession(
          "/api/terminal/session",
          void 0,
          { secret: this.credential.secret, pubkey: getPublicKey2(this.key) }
        );
      } catch (e) {
        if (!(e instanceof ApiError) || e.status !== 401) throw e;
        await this.store?.clear();
        this.credential = null;
        this.error("Sign-in expired. Use /signin.");
      }
    }
    if (!this.session) {
      this.session = await this.requestSession("/api/session", void 0, {
        pubkey: getPublicKey2(this.key)
      });
      await this.request("/api/identity/guest", this.token, {});
    }
    if (this.disposed) throw Error("Client closed.");
    return this.config;
  }
  async requestSession(path, token, body, method = "POST") {
    return sessionSchema.parse(await this.request(path, token, body, method));
  }
  async remember(save = true) {
    this.session = await this.requestSession(
      "/api/session",
      this.token,
      void 0,
      "GET"
    );
    if (!save || !this.store || !this.session.member || this.session.member.accountKind === "guest")
      return;
    const credential = this.credential ?? {
      secret: randomBytes(32).toString("base64url")
    };
    await this.store.save(credential);
    this.credential = credential;
    this.session = await this.requestSession(
      "/api/terminal/enroll",
      this.token,
      { secret: credential.secret }
    );
  }
  async signout() {
    if (this.credential) {
      this.credential = { ...this.credential, revoking: true };
      await this.store.save(this.credential);
      try {
        await this.request("/api/terminal/revoke", void 0, {
          secret: this.credential.secret
        });
      } catch {
        return false;
      }
      await this.store.clear();
      this.credential = null;
    } else if (this.session)
      await this.request("/api/session", this.token, void 0, "DELETE");
    return true;
  }
  close() {
    this.lifetime.abort();
    super.close();
  }
};

// src/cli/text.ts
import stringWidth from "string-width";
import { stripVTControlCharacters } from "node:util";
var segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
var graphemes = (text) => Array.from(segmenter.segment(text), (s) => s.segment);
var clean = (text) => stripVTControlCharacters(text).replace(
  /[\x00-\x1f\x7f-\x9f\u202a-\u202e\u2066-\u2069]/g,
  ""
);
var roomLabel = (topic) => "#" + clean(topic).toLowerCase();
function clip(text, width) {
  let result = "", n = 0;
  for (const char of graphemes(text)) {
    const w = stringWidth(char);
    if (n + w > width) break;
    result += char;
    n += w;
  }
  return result;
}
function wrap(text, width) {
  const lines = [];
  let line = "", n = 0;
  for (const char of graphemes(clean(text))) {
    const w = stringWidth(char);
    if (n + w > width && line) {
      lines.push(line);
      line = "";
      n = 0;
    }
    line += char;
    n += w;
  }
  lines.push(line);
  return lines;
}
function insert(draft, text) {
  const chars = graphemes(draft.text), incoming = graphemes(clean(text.replace(/[\r\n\t]+/g, " ")));
  const left = chars.slice(0, draft.cursor).join("");
  const right = chars.slice(draft.cursor).join("");
  let value = "";
  for (const c of incoming) {
    if (left.length + value.length + c.length + right.length > 500) break;
    value += c;
  }
  return { text: left + value + right, cursor: graphemes(left + value).length };
}

// src/cli/preferences.ts
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { join } from "node:path";
import { homedir } from "node:os";
import { randomUUID } from "node:crypto";
var themes = ["terminal", "green", "blue", "amber", "pink"];
var directory = () => join(process.env.XDG_CONFIG_HOME || join(homedir(), ".config"), "cypher");
async function loadTheme() {
  try {
    const { theme } = JSON.parse(
      await readFile(join(directory(), "preferences.json"), "utf8")
    );
    return themes.includes(theme) ? theme : "terminal";
  } catch {
    return "terminal";
  }
}
async function saveTheme(theme) {
  const dir = directory();
  await mkdir(dir, { recursive: true, mode: 448 });
  const temp = join(dir, `preferences-${randomUUID()}.json`);
  await writeFile(temp, JSON.stringify({ theme }), { mode: 384, flag: "wx" });
  await rename(temp, join(dir, "preferences.json"));
}

// src/cli/controller.ts
var tabs = ["chat", "rooms", "people", "settings"];
function terminalApp(platform = process.platform, env = process.env) {
  const id = env.__CFBundleIdentifier;
  return platform === "darwin" && id && /^[A-Za-z0-9][A-Za-z0-9.-]*$/.test(id) ? id : void 0;
}
var Controller = class {
  constructor(origin, store, theme, persistTheme, join3, copy = copyText, askToSaveSignin = false) {
    this.origin = origin;
    this.store = store;
    this.persistTheme = persistTheme;
    this.copy = copy;
    this.askToSaveSignin = askToSaveSignin;
    this.theme = theme;
    this.makeClient();
    if (join3) this.client.enterBy(join3);
  }
  origin;
  store;
  persistTheme;
  copy;
  askToSaveSignin;
  /** /open sent the sign-in link to a browser on this computer, which now has the focus. */
  openedHere = false;
  client;
  snapshot;
  connection = "connecting";
  notice = "";
  view = "chat";
  selected = 0;
  query = "";
  /** Rooms view: the field is naming a new room, not searching. */
  naming = false;
  draft = { text: "", cursor: 0 };
  drafts = /* @__PURE__ */ new Map();
  /** A guest's message, waiting while they pick a name. Only their own Enter sends it. */
  held;
  theme;
  invitation;
  authPending = false;
  authInput = "";
  sending = false;
  saveSigninPrompt = false;
  savingSignin = false;
  scroll = 0;
  authGeneration = 0;
  authStart;
  authKind;
  authTimer;
  /** Set when a poll shows an unnamed account: the greeting is "Welcome", not "Welcome back". */
  authNew = false;
  /** The account as sign-in began; room snapshots may update before the poll finishes. */
  authFrom;
  welcomeTimer;
  disposed = false;
  version = 0;
  listeners = /* @__PURE__ */ new Set();
  subscribe = (listener) => {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  };
  getVersion = () => this.version;
  changed = () => {
    if (this.disposed) return;
    this.version++;
    for (const listener of this.listeners) listener();
  };
  makeClient() {
    const client = new TerminalClient(
      this.origin,
      this.store,
      (s) => {
        if (this.client !== client) return;
        if (this.held && (s.roomId !== this.snapshot?.roomId || s.self.accountKind !== "guest"))
          this.release();
        if (s.roomId !== this.snapshot?.roomId) {
          if (this.snapshot?.roomId)
            this.drafts.set(this.snapshot.roomId, this.draft);
          this.draft = this.drafts.get(s.roomId ?? "") ?? {
            text: "",
            cursor: 0
          };
          this.scroll = 0;
        }
        this.snapshot = s;
        this.changed();
      },
      (s) => {
        if (this.client === client) {
          this.connection = s;
          this.changed();
        }
      },
      (s) => {
        if (this.client === client) {
          this.notice = clean(s);
          this.changed();
        }
      }
    );
    this.client = client;
  }
  async start() {
    this.notice = "";
    this.connection = "connecting";
    this.changed();
    try {
      await this.client.initialize();
      if (!this.disposed) this.client.connect();
    } catch (e) {
      this.report(e);
      this.connection = "closed";
      this.changed();
    }
  }
  report(e) {
    this.notice = clean(e instanceof Error ? e.message : "Request failed.");
    this.changed();
  }
  /** Picking a name for the message that waits; a sign-in page covers it. */
  get claiming() {
    return !!this.held && !this.invitation && !this.authPending;
  }
  /** The waiting message goes back to its room's composer, unsent. */
  release() {
    const held = this.held;
    if (!held) return;
    this.held = void 0;
    const draft = { text: held.text, cursor: graphemes(held.text).length };
    if (held.roomId === this.snapshot?.roomId) this.draft = draft;
    else this.drafts.set(held.roomId ?? "", draft);
    this.changed();
  }
  /**
   * Enter in the terminal's composer. A guest has no name, so their message
   * waits and the composer asks for one, as the app's claim card does.
   */
  async send() {
    const text = this.draft.text.trim();
    if (!text || text.startsWith("/") || this.view !== "chat")
      return this.submit();
    if (this.held) {
      this.draft = { text: "", cursor: 0 };
      try {
        await this.claim(text);
      } catch (e) {
        if (!this.draft.text)
          this.draft = { text, cursor: graphemes(text).length };
        this.report(e);
      }
      return;
    }
    if (this.snapshot?.self.accountKind !== "guest") return this.submit();
    this.held = { roomId: this.snapshot.roomId, text };
    this.draft = { text: "", cursor: 0 };
    this.notice = "";
    this.scroll = 0;
    this.changed();
  }
  /** Copies the sign-in link, to paste into a browser. */
  async copyLink() {
    if (!this.invitation) return;
    if (await this.copy(this.invitation.url)) {
      this.notice = "link copied";
      this.fadeNotice(this.notice);
    } else this.notice = "select the link above to copy it";
    this.changed();
  }
  switchView(view) {
    if (view !== "chat") this.release();
    this.naming = false;
    this.view = view;
    this.selected = view === "theme" ? themes.indexOf(this.theme) : 0;
    this.query = "";
    this.scroll = 0;
    this.changed();
  }
  /** What the rooms list is filtered by: nothing while the field names a room. */
  get search() {
    return this.naming ? "" : this.query;
  }
  rooms() {
    return this.snapshot?.rooms.filter(
      (r) => r.topic.toLowerCase().includes(this.search.toLowerCase())
    ) ?? [];
  }
  /** The rooms list ends in "start a room": its row. */
  get startRow() {
    return this.rooms().length + (!this.search ? this.snapshot?.lockedRoomCount ?? 0 : 0);
  }
  /** Starts a room called `topic` and moves you into it. */
  async create(topic) {
    await this.client.command({ type: "create", topic: topic.trim() });
    this.switchView("chat");
  }
  people() {
    return this.snapshot?.members.filter(
      (m) => m.roomId === this.snapshot?.roomId && m.id !== this.snapshot?.self.id
    ) ?? [];
  }
  /** The link that brings someone to the room you are in. */
  get inviteLink() {
    const room = this.snapshot?.rooms.find(
      (r) => r.id === this.snapshot?.roomId
    );
    const site = this.client.config?.origin ?? this.origin;
    return room?.code ? inviteLink(site, room.code) : null;
  }
  /** Copies the invite link; where nothing can copy, shows it to select. */
  async invite() {
    const link = this.inviteLink;
    if (!link) throw Error("Join a room first.");
    if (await this.copy(link)) {
      this.notice = "invite link copied";
      this.fadeNotice(this.notice);
    } else this.notice = link;
    this.changed();
  }
  settings() {
    if (!this.snapshot || this.snapshot.self.accountKind === "guest")
      return ["sign in", "theme"];
    return [
      "name",
      "sign out",
      ...!this.snapshot?.self.humanVerified ? ["verify with world id"] : [],
      "theme"
    ];
  }
  count() {
    return this.view === "rooms" ? this.startRow + 1 : this.view === "people" ? this.people().length : this.view === "settings" ? this.settings().length : this.view === "theme" ? themes.length : 0;
  }
  select(direction) {
    const n = this.count();
    if (this.naming) this.query = "";
    this.naming = false;
    if (n) this.selected = (this.selected + direction + n) % n;
    this.changed();
  }
  async activate() {
    if (this.authPending) return;
    try {
      if (this.view === "rooms") {
        const room = this.rooms()[this.selected];
        if (this.naming) {
          if (this.query.trim()) await this.create(this.query);
        } else if (room) {
          await this.client.command({ type: "join", roomId: room.id });
          this.switchView("chat");
        } else if (this.selected !== this.startRow) await this.signin("verify");
        else if (this.snapshot?.self.accountKind === "guest")
          await this.signin("signin");
        else {
          this.naming = true;
          this.selected = this.startRow;
        }
      } else if (this.view === "people") {
        const p = this.people()[this.selected];
        if (p)
          await this.client.command({
            type: "ignore",
            memberId: p.id,
            ignored: !this.snapshot?.ignored.includes(p.id)
          });
      } else if (this.view === "settings") {
        const action = this.settings()[this.selected];
        if (action === "theme") this.switchView("theme");
        else if (action === "name") {
          this.switchView("chat");
          this.draft = { text: "/nick ", cursor: 6 };
        } else if (action === "sign in") await this.signin("signin");
        else if (action === "sign out") await this.signout();
        else await this.signin("verify");
      } else if (this.view === "theme") {
        const theme = themes[this.selected];
        await this.persistTheme(theme);
        this.theme = theme;
        this.switchView("settings");
      }
    } catch (e) {
      this.report(e);
    }
    this.changed();
  }
  async submit() {
    const original = this.draft.text, text = original.trim();
    if (!text || this.sending) return;
    if (text.startsWith("/")) {
      this.draft = { text: "", cursor: 0 };
      const [command, ...parts] = text.split(/\s+/), arg = parts.join(" ");
      try {
        if (command === "/signin") await this.signin("signin");
        else if (command === "/verify") await this.signin("verify");
        else if (command === "/signout") await this.signout();
        else if (command === "/open") await this.open();
        else if (command === "/rooms") this.switchView("rooms");
        else if (command === "/who") this.switchView("people");
        else if (command === "/settings") this.switchView("settings");
        else if (command === "/theme") this.switchView("theme");
        else if (command === "/help") this.switchView("help");
        else if (command === "/nick")
          await this.client.request("/api/account/name", this.client.token, {
            gamertag: arg
          });
        else if (command === "/invite") await this.invite();
        else if (command === "/join") {
          const rooms = this.snapshot?.rooms ?? [];
          const link = arg.includes("join=");
          const code = inviteCode(arg);
          const named = () => rooms.find(
            (r) => r.topic.toLowerCase() === arg.replace(/^#/, "").toLowerCase() || arg === "situation" && r.topic === "Situation Room"
          );
          const room = (code ? rooms.find((r) => r.code === code) : void 0) ?? (link ? void 0 : named());
          if (room) {
            await this.client.command({ type: "join", roomId: room.id });
            this.switchView("chat");
          } else if (link) throw Error("That room is unavailable.");
          else this.switchView("rooms");
        } else throw Error("Unknown command. /help");
      } catch (e) {
        this.report(e);
      }
      this.changed();
      return;
    }
    if (this.view !== "chat" || this.invitation || this.authPending) return;
    if (this.connection !== "connected") {
      this.notice = "reconnecting \xB7 draft saved";
      this.changed();
      return;
    }
    this.sending = true;
    this.changed();
    const roomId = this.snapshot?.roomId;
    try {
      await this.client.post(text);
      if (this.snapshot?.roomId === roomId && this.draft.text === original)
        this.draft = { text: "", cursor: 0 };
      if (this.drafts.get(roomId ?? "")?.text === original)
        this.drafts.delete(roomId ?? "");
      this.notice = "";
    } catch (e) {
      this.report(e);
    } finally {
      this.sending = false;
      this.changed();
    }
  }
  /**
   * Enters `text` as if typed into the chat view, for a client that keeps its
   * own composer (the Claude Code pane). True once a message was delivered or
   * a command ran; a message that was not delivered is reported in `notice`.
   */
  async enter(text) {
    this.view = "chat";
    this.draft = { text, cursor: 0 };
    await this.submit();
    const done = this.draft.text === "" || text.trim().startsWith("/");
    this.draft = { text: "", cursor: 0 };
    return done;
  }
  /**
   * Opens a sign-in that makes a new account called `name`, the way the app's
   * claim card does. The answers are the card's own words.
   */
  async claim(name) {
    const typed = name.trim();
    const { status } = await this.client.request(
      `/api/names/check?name=${encodeURIComponent(typed)}`,
      void 0,
      void 0,
      "GET"
    );
    if (status === "invalid") throw Error("Letters, numbers and _ only.");
    if (status === "account") throw Error("Taken. That you? /signin");
    if (status !== "available") throw Error("Taken.");
    await this.signin("signin", typed);
  }
  /** With `name`, the sign-in registers a new account holding that name. */
  async signin(kind, name) {
    if (this.authPending || this.invitation) return;
    if (!this.snapshot) throw Error("Wait for the room to connect.");
    if (kind === "signin" && this.snapshot.self.accountKind !== "guest") return;
    const generation = ++this.authGeneration;
    this.authKind = kind;
    this.authNew = name !== void 0;
    this.authFrom = this.snapshot.self;
    this.authPending = true;
    this.notice = "";
    this.changed();
    try {
      const start = this.client.request(
        kind === "signin" ? "/api/passkey/start" : "/api/identity/start",
        this.client.token,
        name === void 0 ? {} : { name }
      );
      this.authStart = start;
      const result = await start;
      if (generation !== this.authGeneration || this.disposed) return;
      let url = result.url ?? result.verificationUri;
      if (!url) throw Error("No sign-in link was returned.");
      const parsed = new URL(url);
      if (kind === "signin" ? parsed.origin !== this.origin && parsed.origin !== this.client.config?.origin : parsed.protocol !== "https:")
        throw Error("Unexpected sign-in address.");
      if (kind === "signin") {
        parsed.searchParams.set("source", "terminal");
        url = parsed.href;
      }
      this.openedHere = false;
      this.invitation = {
        kind,
        url,
        lines: qrLines(url),
        code: result.userCode,
        expires: Date.now() + 3e5,
        name
      };
      this.poll(generation);
    } finally {
      if (generation === this.authGeneration) {
        this.authPending = false;
        this.changed();
      }
    }
  }
  poll(generation) {
    this.authTimer = setTimeout(async () => {
      if (generation !== this.authGeneration || !this.invitation || this.disposed)
        return;
      const kind = this.invitation.kind;
      if (Date.now() > this.invitation.expires) {
        await this.cancelSignin();
        this.notice = "link expired \xB7 /signin to retry";
        this.changed();
        return;
      }
      try {
        const result = await this.client.request(
          kind === "signin" ? "/api/identity" : "/api/identity/poll",
          this.client.token,
          void 0,
          kind === "signin" ? "GET" : "POST"
        );
        if (generation !== this.authGeneration || this.disposed) return;
        if (result.member?.needsName) this.authNew = true;
        if (kind === "signin" ? result.handoffComplete && !result.member?.needsName : result.member?.humanVerified) {
          this.invitation = void 0;
          this.authKind = void 0;
          this.returnFocus();
          const welcome = result.member ? welcomeFor(this.authFrom, result.member, this.authNew) : null;
          let saved = "";
          try {
            await this.client.remember(!this.askToSaveSignin);
            if (this.askToSaveSignin || !this.store) saved = "signed in for this session";
            if (this.askToSaveSignin && kind === "signin" && this.store && result.member && result.member.accountKind !== "guest")
              this.saveSigninPrompt = true;
          } catch {
            saved = "signed in for this session \xB7 could not save terminal credentials";
          }
          if (generation !== this.authGeneration || this.disposed) return;
          this.notice = [welcome, saved].filter(Boolean).join(" \xB7 ");
          if (welcome && !saved) this.fadeNotice(this.notice);
          this.changed();
          return;
        }
      } catch (e) {
        if (generation !== this.authGeneration || this.disposed) return;
        this.report(e);
      }
      if (generation === this.authGeneration) this.poll(generation);
    }, 1500);
  }
  /** The browser took the focus for sign-in; bring this terminal's app forward again. A phone sign-in never moved it. */
  returnFocus() {
    const app = this.openedHere ? terminalApp() : void 0;
    this.openedHere = false;
    if (!app) return;
    const child = spawn2("open", ["-b", app], { stdio: "ignore", shell: false });
    child.on("error", () => {
    });
    child.unref();
  }
  /** Clears a transient notice after a few seconds unless something replaced it. */
  fadeNotice(text) {
    clearTimeout(this.welcomeTimer);
    this.welcomeTimer = setTimeout(() => {
      if (this.disposed || this.notice !== text) return;
      this.notice = "";
      this.changed();
    }, 4e3);
    this.welcomeTimer.unref?.();
  }
  async cancelSignin() {
    const kind = this.authKind;
    this.authKind = void 0;
    ++this.authGeneration;
    clearTimeout(this.authTimer);
    this.invitation = void 0;
    this.authInput = "";
    this.authPending = !!kind;
    this.changed();
    try {
      await this.authStart?.catch(() => {
      });
      if (kind)
        await this.client.request(
          kind === "signin" ? "/api/passkey/cancel" : "/api/identity/cancel",
          this.client.token,
          {}
        );
    } catch (e) {
      this.report(e);
    } finally {
      this.authStart = void 0;
      this.authPending = false;
      this.changed();
    }
  }
  toggleNewAccount() {
    if (this.invitation?.kind !== "signin" || this.invitation.name) return;
    const url = new URL(this.invitation.url);
    if (url.searchParams.has("action")) url.searchParams.delete("action");
    else url.searchParams.set("action", "register");
    this.invitation = {
      ...this.invitation,
      url: url.href,
      lines: qrLines(url.href)
    };
    this.changed();
  }
  async open() {
    if (!this.invitation) throw Error("Use /signin first.");
    const url = this.invitation.url;
    const [command, args] = process.platform === "darwin" ? ["open", [url]] : process.platform === "win32" ? ["rundll32", ["url.dll,FileProtocolHandler", url]] : ["xdg-open", [url]];
    await new Promise((resolve, reject) => {
      const child = spawn2(command, args, { stdio: "ignore", shell: false });
      child.on(
        "error",
        () => reject(Error("Could not open browser. Use the link above."))
      );
      child.on(
        "exit",
        (code) => code === 0 ? resolve() : reject(Error("Could not open browser. Use the link above."))
      );
    });
    this.openedHere = true;
  }
  async chooseSaveSignin(save) {
    if (!this.saveSigninPrompt || this.savingSignin || this.disposed) return;
    this.saveSigninPrompt = false;
    if (!save) {
      this.notice = "signed in for this session";
      this.changed();
      return;
    }
    const client = this.client;
    this.savingSignin = true;
    this.changed();
    try {
      await client.remember();
      if (this.client === client && !this.disposed)
        this.notice = "sign-in saved on this device";
    } catch {
      if (this.client === client && !this.disposed)
        this.notice = "still signed in \xB7 could not save sign-in on this device";
    } finally {
      this.savingSignin = false;
      this.changed();
    }
  }
  async signout() {
    this.saveSigninPrompt = false;
    await this.cancelSignin();
    const revoked = await this.client.signout();
    this.client.close();
    this.snapshot = void 0;
    this.held = void 0;
    this.drafts.clear();
    this.draft = { text: "", cursor: 0 };
    if (!revoked) {
      this.store = null;
      this.notice = "signed out here \xB7 remote revocation pending; retry on next launch";
    }
    this.makeClient();
    await this.start();
    this.switchView("chat");
  }
  close() {
    if (this.disposed) return;
    this.disposed = true;
    ++this.authGeneration;
    clearTimeout(this.authTimer);
    clearTimeout(this.welcomeTimer);
    this.client.close();
    this.drafts.clear();
    this.snapshot = void 0;
    this.draft = { text: "", cursor: 0 };
  }
};

// src/cli/view.tsx
import { useEffect, useSyncExternalStore } from "react";
import { Box, Text, useApp, useInput, usePaste, useWindowSize } from "ink";
import { once } from "node:events";
import stringWidth2 from "string-width";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var colors = {
  terminal: void 0,
  green: "green",
  blue: "blue",
  amber: "yellow",
  pink: "magentaBright"
};
function TerminalView({ model }) {
  useSyncExternalStore(model.subscribe, model.getVersion);
  const { columns, rows } = useWindowSize(), { exit, suspendTerminal } = useApp();
  const width = Math.max(8, columns - 4), bodyHeight = Math.max(1, rows - 9);
  const accent = process.env.NO_COLOR !== void 0 ? void 0 : colors[model.view === "theme" ? themes[model.selected] : model.theme];
  const quit = () => {
    model.close();
    exit();
  };
  useEffect(() => {
    const stop = () => quit();
    process.once("SIGTERM", stop);
    process.stdin.once("end", stop);
    return () => {
      process.off("SIGTERM", stop);
      process.stdin.off("end", stop);
    };
  }, []);
  const edit = (text) => {
    model.draft = insert(model.draft, text);
    model.changed();
  };
  usePaste((text) => {
    if (model.invitation || model.authPending || model.saveSigninPrompt || model.savingSignin) return;
    if (model.view === "rooms") {
      model.query = clean(text).slice(0, 100);
      if (!model.naming) model.selected = 0;
      model.changed();
    } else edit(text);
  });
  useInput((input, key) => {
    if (key.ctrl && (input === "c" || input === "d")) {
      quit();
      return;
    }
    if (model.saveSigninPrompt || model.savingSignin) {
      if (!model.savingSignin) {
        if (input.toLowerCase() === "y") void model.chooseSaveSignin(true);
        else if (input.toLowerCase() === "n" || key.escape || key.return)
          void model.chooseSaveSignin(false);
      }
      return;
    }
    if (key.ctrl && input === "r" && model.connection === "closed") {
      void model.start();
      return;
    }
    if (key.ctrl && input === "z" && process.platform !== "win32") {
      void suspendTerminal(async () => {
        const resumed = once(process, "SIGCONT");
        process.kill(process.pid, "SIGSTOP");
        await resumed;
      }).catch((e) => model.report(e));
      return;
    }
    if (model.invitation || model.authPending) {
      if (key.escape) void model.cancelSignin();
      else if (key.return) {
        if (!["", "/open", "/open browser"].includes(model.authInput.trim()))
          model.report(Error("enter opens the browser \xB7 esc returns to chat"));
        else {
          model.authInput = "";
          void model.open().catch((e) => model.report(e));
        }
      } else if (!model.authInput && input === "n") model.toggleNewAccount();
      else if (!model.authInput && input === "c") void model.copyLink();
      else if (!model.authInput && input === "o")
        void model.open().catch((e) => model.report(e));
      else if (key.backspace || key.delete)
        model.authInput = graphemes(model.authInput).slice(0, -1).join("");
      else if (!key.ctrl && !key.meta)
        model.authInput = clean(model.authInput + input).slice(0, 30);
      model.changed();
      return;
    }
    if (key.escape && model.naming) {
      model.naming = false;
      model.query = "";
      model.changed();
      return;
    }
    if (key.escape) {
      model.release();
      model.switchView(model.view === "theme" ? "settings" : "chat");
      return;
    }
    if (key.pageUp || key.pageDown) {
      model.scroll = Math.max(
        0,
        model.scroll + (key.pageUp ? bodyHeight : -bodyHeight)
      );
      model.changed();
      return;
    }
    if (key.tab || (key.leftArrow || key.rightArrow) && !model.draft.text) {
      const index = Math.max(
        0,
        tabs.indexOf(
          model.view === "theme" ? "settings" : model.view
        )
      );
      model.switchView(
        tabs[(index + (key.shift || key.leftArrow ? -1 : 1) + tabs.length) % tabs.length]
      );
      return;
    }
    if (key.upArrow || key.downArrow) {
      if (model.view === "chat") model.switchView("rooms");
      else model.select(key.upArrow ? -1 : 1);
      return;
    }
    if (key.return) {
      if (model.draft.text.trim() === "/exit" || model.draft.text.trim() === "/quit") {
        quit();
        return;
      }
      if (model.view !== "chat" && !model.draft.text.startsWith("/"))
        void model.activate();
      else void model.send();
      return;
    }
    if (model.view === "rooms" && !model.draft.text.startsWith("/")) {
      if (key.backspace || key.delete)
        model.query = graphemes(model.query).slice(0, -1).join("");
      else if (!key.ctrl && !key.meta) model.query += clean(input);
      model.query = model.query.slice(0, 100);
      if (!model.naming) model.selected = 0;
      model.changed();
      return;
    }
    if (input === "?" && !model.draft.text) {
      model.switchView("help");
      return;
    }
    const draft = model.draft, chars2 = graphemes(draft.text);
    if (key.leftArrow) draft.cursor = Math.max(0, draft.cursor - 1);
    else if (key.rightArrow)
      draft.cursor = Math.min(chars2.length, draft.cursor + 1);
    else if (key.home || key.ctrl && input === "a") draft.cursor = 0;
    else if (key.end || key.ctrl && input === "e")
      draft.cursor = chars2.length;
    else if (key.ctrl && input === "u") {
      draft.text = chars2.slice(draft.cursor).join("");
      draft.cursor = 0;
    } else if (key.backspace) {
      if (draft.cursor) {
        chars2.splice(--draft.cursor, 1);
        draft.text = chars2.join("");
      }
    } else if (key.delete) {
      chars2.splice(draft.cursor, 1);
      draft.text = chars2.join("");
    } else if (!key.ctrl && !key.meta) edit(input);
    model.changed();
  });
  if (model.saveSigninPrompt || model.savingSignin)
    return /* @__PURE__ */ jsxs(Box, { padding: 2, flexDirection: "column", children: [
      /* @__PURE__ */ jsx(Text, { color: accent, children: "cypher" }),
      /* @__PURE__ */ jsx(Text, { children: " " }),
      /* @__PURE__ */ jsx(Text, { children: "You\u2019re signed in." }),
      /* @__PURE__ */ jsx(Text, { children: model.savingSignin ? "Saving sign-in\u2026" : process.platform === "darwin" ? "Save this sign-in on this Mac?" : "Save this sign-in on this device?" }),
      /* @__PURE__ */ jsx(Text, { children: process.platform === "darwin" ? "Uses macOS Keychain to remember you." : "Uses your operating system\u2019s credential store to remember you." }),
      /* @__PURE__ */ jsx(Text, { children: " " }),
      !model.savingSignin && /* @__PURE__ */ jsx(Text, { children: "y Save \xB7 enter/n Not now \xB7 esc Not now" })
    ] });
  const s = model.snapshot, self = s?.self, currentRoom = s?.rooms.find((r) => r.id === s.roomId), guest = self?.accountKind === "guest";
  const name = (value, verified) => /* @__PURE__ */ jsxs(Fragment, { children: [
    /* @__PURE__ */ jsx(Text, { bold: true, children: clean(value) }),
    verified && /* @__PURE__ */ jsx(Text, { color: accent, children: " \u2713" })
  ] });
  const body = [];
  const add = (value) => body.push(value);
  if (model.invitation) {
    const invitation = model.invitation;
    add(
      /* @__PURE__ */ jsx(Text, { color: accent, children: invitation.kind === "signin" ? invitation.name || invitation.url.includes("action=register") ? "create account" : "sign in" : "verify with world id" })
    );
    const linkLines = wrap(invitation.url, width);
    if (process.env.NO_COLOR !== void 0) {
    } else if (invitation.lines.length + linkLines.length + 3 <= bodyHeight && invitation.lines[0].reduce((n, run) => n + run.text.length, 0) <= width)
      for (const line of invitation.lines)
        add(
          /* @__PURE__ */ jsx(Text, { children: line.map((run, index) => /* @__PURE__ */ jsx(
            Text,
            {
              color: run.foreground,
              backgroundColor: run.background,
              children: run.text
            },
            index
          )) })
        );
    else add(/* @__PURE__ */ jsx(Text, { children: "enlarge terminal for qr" }));
    for (const line of linkLines) add(/* @__PURE__ */ jsx(Text, { children: line }));
    if (invitation.code) add(/* @__PURE__ */ jsx(Text, { children: clean(invitation.code) }));
    add(
      /* @__PURE__ */ jsx(Text, { children: invitation.kind === "signin" && !invitation.name ? `enter open \xB7 c copy \xB7 n ${invitation.url.includes("action=register") ? "sign in" : "create account"} \xB7 esc back` : "enter open \xB7 c copy \xB7 esc back" })
    );
  } else if (model.authPending) add(/* @__PURE__ */ jsx(Text, { children: "connecting\u2026" }));
  else if (model.view === "rooms") {
    for (const [i, room] of model.rooms().entries())
      add(
        /* @__PURE__ */ jsx(
          Text,
          {
            underline: i === model.selected,
            color: i === model.selected ? accent : void 0,
            children: clip(
              `${i === model.selected ? "\u203A" : " "} ${roomLabel(room.topic)} \xB7 ${room.count} here`,
              width
            )
          }
        )
      );
    if (!model.search)
      for (let i = 0; i < (s?.lockedRoomCount ?? 0); i++)
        add(
          /* @__PURE__ */ jsxs(
            Text,
            {
              underline: model.selected === model.rooms().length + i,
              color: accent,
              children: [
                " ",
                model.selected === model.rooms().length + i ? "\u203A" : " ",
                " #######"
              ]
            }
          )
        );
    add(
      /* @__PURE__ */ jsxs(
        Text,
        {
          underline: model.selected === model.startRow,
          color: model.selected === model.startRow ? accent : void 0,
          children: [
            model.selected === model.startRow ? "\u203A" : " ",
            " + start a room"
          ]
        }
      )
    );
  } else if (model.view === "people") {
    if (self)
      add(
        guest ? /* @__PURE__ */ jsx(Text, { bold: true, children: "you" }) : /* @__PURE__ */ jsxs(Text, { children: [
          name(self.gamertag, self.humanVerified),
          " (you)"
        ] })
      );
    for (const [i, p] of model.people().entries())
      add(
        /* @__PURE__ */ jsxs(Text, { underline: i === model.selected, children: [
          i === model.selected ? "\u203A" : " ",
          " ",
          name(p.gamertag, p.humanVerified),
          s?.ignored.includes(p.id) ? " \xB7 muted" : ""
        ] })
      );
  } else if (model.view === "settings") {
    for (const [i, label] of model.settings().entries())
      add(
        /* @__PURE__ */ jsxs(
          Text,
          {
            color: i === model.selected ? accent : void 0,
            underline: i === model.selected,
            children: [
              i === model.selected ? "\u203A" : " ",
              " ",
              label,
              label === "theme" ? ` \xB7 ${model.theme}` : label === "name" ? ` \xB7 ${clean(self?.gamertag ?? "")}` : ""
            ]
          }
        )
      );
  } else if (model.view === "help") {
    for (const line of [
      "/signin \xB7 /verify \xB7 /signout",
      "/rooms \xB7 /join <room or invite> \xB7 /who",
      "/invite copies this room's link",
      "/nick <name> \xB7 /settings \xB7 /theme",
      "/exit",
      "",
      "tab switch \xB7 arrows select \xB7 enter open",
      "pgup / pgdn scroll \xB7 esc back"
    ])
      add(/* @__PURE__ */ jsx(Text, { children: line }));
  } else {
    if (model.view === "theme") {
      themes.forEach(
        (t, i) => add(
          /* @__PURE__ */ jsxs(
            Text,
            {
              color: i === model.selected ? accent : void 0,
              underline: i === model.selected,
              children: [
                i === model.selected ? "\u203A" : " ",
                " ",
                t,
                t === model.theme ? " \xB7 current" : ""
              ]
            }
          )
        )
      );
      add(/* @__PURE__ */ jsx(Text, { children: " " }));
    }
    const messages = (s?.messages ?? []).filter(
      (m) => m.text && !s?.ignored.includes(m.memberId)
    );
    for (const message of model.view === "theme" ? messages.slice(-3) : messages) {
      const prefix = clean(message.gamertag) + (message.humanVerified ? " \u2713" : "") + "  ";
      const available = Math.max(1, width - stringWidth2(prefix));
      const lines = wrap(message.text, available);
      lines.forEach(
        (line, i) => add(
          /* @__PURE__ */ jsxs(Text, { children: [
            i === 0 ? /* @__PURE__ */ jsxs(Fragment, { children: [
              name(message.gamertag, message.humanVerified),
              " "
            ] }) : " ".repeat(Math.min(width - 1, stringWidth2(prefix))),
            /* @__PURE__ */ jsx(Text, { color: message.memberId === self?.id ? accent : void 0, children: line })
          ] })
        )
      );
    }
    if (!messages.length && model.connection === "connected")
      add(/* @__PURE__ */ jsx(Text, { children: " " }));
    if (model.claiming && model.view === "chat") {
      const typed = model.draft.text.trim();
      add(
        /* @__PURE__ */ jsxs(Text, { children: [
          /* @__PURE__ */ jsx(Text, { bold: true, children: typed && !typed.startsWith("/") ? clean(typed) : "\u2026" }),
          " ",
          /* @__PURE__ */ jsx(Text, { color: accent, children: clip(model.held?.text ?? "", Math.max(1, width - 26)) })
        ] })
      );
      add(/* @__PURE__ */ jsx(Text, { children: " " }));
      add(/* @__PURE__ */ jsx(Text, { color: accent, children: "Choose a Cypher name" }));
    }
    if (model.view === "theme")
      add(
        /* @__PURE__ */ jsxs(Text, { color: accent, children: [
          guest ? "you" : clean(self?.gamertag ?? "you"),
          " your message"
        ] })
      );
  }
  let offset = 0;
  if (model.view === "chat")
    offset = Math.max(0, body.length - bodyHeight - model.scroll);
  else if (!model.invitation && ["rooms", "people", "settings"].includes(model.view))
    offset = Math.max(0, model.selected - bodyHeight + 2);
  const visible = body.slice(offset, offset + bodyHeight);
  let hint = model.invitation ? "" : model.view === "theme" ? "\u2191\u2193 preview \xB7 enter save \xB7 esc cancel" : model.view === "chat" ? model.claiming ? "enter join the chat \xB7 /signin sign in \xB7 esc cancel" : "tab switch \xB7 ? help" : model.naming ? "name your room \xB7 enter start \xB7 esc cancel" : "\u2191\u2193 select \xB7 enter open \xB7 esc back";
  const chars = graphemes(model.draft.text), left = chars.slice(0, model.draft.cursor);
  while (stringWidth2(left.join("")) > width - 4) left.shift();
  const before = left.join(""), at = chars[model.draft.cursor] ?? " ", after = clip(
    chars.slice(model.draft.cursor + 1).join(""),
    Math.max(0, width - 3 - stringWidth2(before) - stringWidth2(at))
  );
  if (rows < 12 || columns < 36)
    return /* @__PURE__ */ jsx(Text, { children: "resize to 36 \xD7 12 \xB7 ctrl+c exits" });
  return /* @__PURE__ */ jsxs(
    Box,
    {
      width: columns,
      height: rows,
      paddingX: 2,
      paddingTop: 1,
      flexDirection: "column",
      children: [
        /* @__PURE__ */ jsxs(Box, { justifyContent: "space-between", children: [
          /* @__PURE__ */ jsx(Text, { color: accent, children: "cypher" }),
          /* @__PURE__ */ jsx(Text, { children: guest ? "sign in" : clean(self?.gamertag ?? "") })
        ] }),
        /* @__PURE__ */ jsx(Text, { children: tabs.map((tab) => /* @__PURE__ */ jsxs(
          Text,
          {
            color: model.view === tab || model.view === "theme" && tab === "settings" ? accent : void 0,
            underline: model.view === tab || model.view === "theme" && tab === "settings",
            children: [
              tab,
              " "
            ]
          },
          tab
        )) }),
        /* @__PURE__ */ jsx(Text, { children: clip(
          currentRoom ? `${roomLabel(currentRoom.topic)} \xB7 ${currentRoom.count} here \xB7 /invite copies link` : model.connection,
          width
        ) }),
        /* @__PURE__ */ jsx(Text, { children: " " }),
        /* @__PURE__ */ jsx(Box, { height: bodyHeight, flexDirection: "column", children: visible.map((line, i) => /* @__PURE__ */ jsx(Box, { height: 1, children: line }, i)) }),
        /* @__PURE__ */ jsx(Text, { children: clip(
          clean(
            model.notice || (model.connection !== "connected" ? model.connection : guest && !model.invitation && !model.claiming ? "/signin" : "")
          ),
          width
        ) }),
        /* @__PURE__ */ jsx(Text, { children: hint }),
        /* @__PURE__ */ jsxs(Text, { children: [
          /* @__PURE__ */ jsx(Text, { color: accent, children: "\u203A " }),
          model.invitation ? model.authInput : model.view === "rooms" ? model.query : /* @__PURE__ */ jsxs(Fragment, { children: [
            before,
            /* @__PURE__ */ jsx(Text, { inverse: true, children: at }),
            after
          ] })
        ] })
      ]
    }
  );
}

// src/cli/codex-credentials.ts
import { createHash as createHash2, randomUUID as randomUUID2 } from "node:crypto";
import { mkdir as mkdir2, readFile as readFile2, rename as rename2, writeFile as writeFile2 } from "node:fs/promises";
import { homedir as homedir2 } from "node:os";
import { join as join2 } from "node:path";

// src/cli/credentials.ts
import { z as z4 } from "zod";
import { createHash } from "node:crypto";
var credentialRecord = z4.object({
  secret: z4.string().regex(/^[A-Za-z0-9_-]{43}$/),
  revoking: z4.boolean().optional()
});
async function systemCredentials(origin, service = "org.cypher.terminal") {
  const { AsyncEntry } = await import("@napi-rs/keyring");
  const entry = new AsyncEntry(
    service,
    createHash("sha256").update(origin).digest("hex")
  );
  return {
    async load() {
      const value = await entry.getPassword();
      return value ? credentialRecord.parse(JSON.parse(value)) : null;
    },
    async save(value) {
      await entry.setPassword(JSON.stringify(credentialRecord.parse(value)));
    },
    async clear() {
      await entry.deleteCredential();
    }
  };
}

// src/cli/codex-credentials.ts
function codexCredentials(origin, factory = () => systemCredentials(origin, "org.cypher.codex-terminal"), directory2 = join2(process.env.XDG_CONFIG_HOME || join2(homedir2(), ".config"), "cypher")) {
  const file = join2(directory2, `codex-signin-${createHash2("sha256").update(origin).digest("hex")}.json`);
  let store;
  const get = () => store ??= factory();
  const consent = async (saved) => {
    await mkdir2(directory2, { recursive: true, mode: 448 });
    const temp = `${file}.${randomUUID2()}`;
    await writeFile2(temp, JSON.stringify({ saved }), { mode: 384, flag: "wx" });
    await rename2(temp, file);
  };
  return {
    async load() {
      let saved = false;
      try {
        saved = JSON.parse(await readFile2(file, "utf8")).saved === true;
      } catch (error) {
        if (error.code !== "ENOENT") throw error;
      }
      return saved ? (await get()).load() : null;
    },
    // Called only after the post-login Save choice (or revoking a saved device).
    async save(value) {
      await (await get()).save(value);
      await consent(true);
    },
    async clear() {
      await (await get()).clear();
      await consent(false);
    }
  };
}

// src/cli/main.tsx
import { jsx as jsx2 } from "react/jsx-runtime";
var { values } = parseArgs({
  options: {
    origin: { type: "string", default: "http://localhost:3137" },
    join: { type: "string" },
    "session-only": { type: "boolean" },
    codex: { type: "boolean" },
    help: { type: "boolean", short: "h" }
  },
  allowPositionals: false
});
if (values.help) {
  console.log(
    "cypher [--origin https://your-cypher-service] [--join <invite link or code>] [--session-only] [--codex]\n--codex asks to save after login; saved sign-ins restore on later launches.\nRun in a dedicated terminal beside Codex or Claude Code.\nLocal default: http://localhost:3137"
  );
} else if (!process.stdin.isTTY || !process.stdout.isTTY || process.env.TERM === "dumb") {
  console.error(
    "Open Cypher in an interactive terminal pane. Use --help for options."
  );
  process.exitCode = 1;
} else {
  let model;
  try {
    const origin = normalizeOrigin(values.origin);
    const store = values["session-only"] ? null : values.codex ? codexCredentials(origin) : await systemCredentials(origin);
    if (store && !values.codex) await store.load();
    model = new Controller(
      origin,
      store,
      await loadTheme(),
      saveTheme,
      values.join,
      void 0,
      values.codex ?? false
    );
    const instance = render(/* @__PURE__ */ jsx2(TerminalView, { model }), {
      alternateScreen: true,
      incrementalRendering: true,
      maxFps: 30,
      exitOnCtrlC: false,
      patchConsole: false
    });
    void model.start();
    try {
      await instance.waitUntilExit();
    } finally {
      model.close();
      instance.cleanup();
    }
  } catch {
    model?.close();
    console.error(
      "Cypher could not start. Check the service address and OS credential store; use --session-only if secure storage is unavailable."
    );
    process.exitCode = 1;
  }
}
